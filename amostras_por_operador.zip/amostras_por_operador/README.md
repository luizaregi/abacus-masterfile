# Amostras por operador físico (fase de operator sampling)

Gerado por `analise_amostragem/build_operator_sampling.py` a partir de `runs/*/observations.csv`.
**Não edite à mão**: o script apaga e regenera as subpastas `cuad/` e `biodex/` a cada execução.

Totais: 322 operadores (biodex: 187, cuad: 135), 15413 linhas de sampling.

## Estrutura

| Caminho | Conteúdo |
|---|---|
| `<benchmark>/NNN__<rotulo>__<full_op_id>.csv` | Todas as observações de sampling de **um** operador físico, de todas as runs, incluindo duplicatas e falhas (marcadas por colunas) |
| `INDEX.csv` | Uma linha por operador: contagens, estatísticas (média, desvio, min, Q1, mediana, Q3, max) de quality, custo e latência, e o caminho do CSV |
| `runs_inventory.csv` | Todas as runs do masterfile, com benchmark, campanha, estratégia, modelos e se têm observations |

`NNN` segue a ordem: operador lógico, tipo (Scan, Retrieve, Bonded, RAG, Critic, MoA) e rótulo.
No BioDEX o rótulo leva o prefixo `L<n>:`, a posição do operador lógico no plano.

## Colunas de validade (nos CSVs por operador)

| Coluna | Significado |
|---|---|
| `is_duplicate` / `duplicate_of` | Linha com conteúdo idêntico (mesmo registro e mesmas métricas e tokens) a outra já vista em outra run. Ocorre principalmente quando a mesma run foi baixada ou extraída mais de uma vez |
| `failed` | `failed_convert == True` |
| `valid` | `not is_duplicate and not failed`: é a amostra usada nas estatísticas |
| `has_quality` | `quality` preenchida. A campanha `behavior` foi rodada antes do fix de quality e tem `quality` vazia, mas custo e latência válidos |

As estatísticas de quality do `INDEX.csv` usam `valid and has_quality`. As de custo e latência usam `valid`.
`status = ok` quando há pelo menos 5 amostras válidas com quality.

As demais colunas são as do `observations.csv` do masterfile, mais os metadados da run
(`experiment_id`, `campaign`, `sentinel_strategy`, `available_models`, `max_cost`, `sample_budget`, ...).

Para regenerar, depois de baixar novas runs para `runs/`:

```bash
python3 analise_amostragem/build_operator_sampling.py
```
